﻿

byte idade = 25;
ushort publico = 45_239;
float media = 4.5F;
decimal estrela = 4.9847373723M;
bool aprovado = false;
int x;
var y = 5.0;


Console.WriteLine(y.GetType());
Console.ReadKey();
