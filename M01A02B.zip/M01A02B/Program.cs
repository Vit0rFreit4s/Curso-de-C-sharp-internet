﻿

Console.WriteLine("Oi,");
Console.WriteLine("tudo");
Console.WriteLine("Bem");
Console.ReadKey();

Console.WriteLine("Oi, \ntudo \nbem");