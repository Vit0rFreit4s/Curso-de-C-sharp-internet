﻿

Console.WriteLine("Oi");
Console.Write("Tudo bem");
Console.ReadKey();
