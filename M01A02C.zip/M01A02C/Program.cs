﻿


Console.WriteLine("Estud\tonauta");
Console.WriteLine("Estud\bonauta");
Console.WriteLine("Estudonauta\a");
Console.WriteLine("Estudonau\rta");
Console.WriteLine("\\Estudonauta\\");
Console.WriteLine(@"\Estudonaut\a");
Console.WriteLine("\"Estudonauta\"");
Console.ReadKey();
