﻿
//Valores númericos Inteiros
Console.WriteLine("O tipo de byte vai de " + byte.MinValue + " até " + byte.MaxValue);//Usa 1 byte (8 bits)
Console.WriteLine("O tipo de byte vai de " + sbyte.MinValue + " até " + sbyte.MaxValue);//Usa 1 byte (8 bits)
Console.WriteLine("O tipo de byte vai de " + short.MinValue + " até " + short.MaxValue);//Usa 2 byte (16 bits)
Console.WriteLine("O tipo de byte vai de " + ushort.MinValue + " até " + ushort.MaxValue);//Usa 2 byte (16 bits)
Console.WriteLine("O tipo de byte vai de " + int.MinValue + " até " + int.MaxValue);//Usa 4 byte (32 bits)
Console.WriteLine("O tipo de byte vai de " + uint.MinValue + " até " + uint.MaxValue);//Usa 4 byte (32 bits)
Console.WriteLine("O tipo de byte vai de " + long.MinValue + " até " + long.MaxValue);//Usa 8 byte (64 bits)
Console.WriteLine("O tipo de byte vai de " + ulong.MinValue + " até " + ulong.MaxValue);//Usa 8 byte (64 bits)
//Valores numéricos Reais
Console.WriteLine("O tipo float vai de "+ float.MinValue + " até " + float.MaxValue);//Usa 4 byte (32 bits)
Console.WriteLine("O tipo float vai de " + double.MinValue + " até " + double.MaxValue);//Usa 8 byte (64 bits)
Console.WriteLine("O tipo float vai de " + decimal.MinValue + " até " + decimal.MaxValue);//Usa 16 byte (128 bits)
//Valores Lógicos
Console.WriteLine("O tipo bool vai de " + bool.MinValue + " até " + bool.MaxValue);//Usa 1bit (True or False)

Console.ReadKey();
