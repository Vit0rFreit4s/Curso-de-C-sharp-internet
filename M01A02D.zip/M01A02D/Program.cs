﻿

Console.WriteLine("C# é\n\"SUPER\"\nFácil!\a");
Console.ReadKey();