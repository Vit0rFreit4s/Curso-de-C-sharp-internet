﻿


Console.SetCursorPosition(10, 5);

Thread.Sleep(1000);
Console.BackgroundColor = ConsoleColor.Blue;
Console.ForegroundColor = ConsoleColor.White;
Console.Write(" MEU ");
Console.ResetColor();
Thread.Sleep(1000);
Console.BackgroundColor = ConsoleColor.Yellow;
Console.ForegroundColor = ConsoleColor.Green;
Console.Write(" BRASIL ");
Console.ResetColor();
Thread.Sleep(1000);
Console.ForegroundColor = ConsoleColor.Yellow;
Console.BackgroundColor = ConsoleColor.Green;
Console.WriteLine(" BRASILEIRO ");


Console.ReadKey();