﻿
Console.Write("Qual é o seu nome? ")
string nome = Console.ReadLine();
Console.WriteLine("Muito prazer em te conhecer, " + nome + "!");
Console.ReadKey();
