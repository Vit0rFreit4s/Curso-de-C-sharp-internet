﻿
Random gerador = new Random();
int n = gerador.Next(1,4);

Console.WriteLine("Acabei de gerar o número " + n);
Console.ReadKey();
