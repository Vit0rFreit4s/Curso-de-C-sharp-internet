﻿
//Declaração de Variáveis

var nome = "Vitor";

Console.WriteLine("A variável nome tem " + nome);
Console.WriteLine("Nome é do tipo " + nome.GetType());
Console.ReadKey();
