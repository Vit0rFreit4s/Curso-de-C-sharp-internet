﻿

const string ESCOLA = "Estudonauta";
const float PI = 3.1415f;

//ESCOLA = "Curso em Vídeo"; // Comando dá erro!

Console.WriteLine("Eu estudo no " + ESCOLA);
Console.WriteLine("O valor de Pi é " + PI);
Console.WriteLine("O valor oficial de Pi é " + Math.PI);
Console.WriteLine("O tipo de Pi no meu programa é " + PI.GetType());
Console.WriteLine("O tipo de Pi em Math é " + Math.PI.GetType());
Console.ReadKey();